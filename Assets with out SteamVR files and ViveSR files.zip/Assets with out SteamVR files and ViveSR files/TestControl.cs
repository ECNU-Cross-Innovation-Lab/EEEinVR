﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Tobii.G2OM;
using UnityEngine.UI;

namespace Tobii.XR
{
    public class TestControl : MonoBehaviour, IGazeFocusable
{
    // Start is called before the first frame update
    public float timer = 1.8f;
    public GameObject gp;
    public bool flag;
    public int turncount, btcount, totalcount;
    private string cubename, buttonname;
    void Start()
    {
        flag = true;
        turncount = 0;
        btcount = 0;
        totalcount = 0;
        timer = 1.8f;
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void GazeFocusChanged(bool hasFocus)
        {
            //If this object received focus, fade the object's color to highlight color
            if (hasFocus)
            {
                //_targetColor = HighlightColor;
            }
            //If this object lost focus, fade the object's color to it's original color
            else
            {
                //_targetColor = _originalColor;
            }
        }

    void FixedUpdate () {
        //Debug.Log(timer);
        if(timer > 1.0f){
            gp.SetActive(true);
            timer -= Time.fixedDeltaTime;
            cubename = "Cube"+turncount.ToString(); 
        }
        else if(timer > 0.8f){
            gp.SetActive(false);
            timer -= Time.fixedDeltaTime;
            buttonname = "Button"+btcount.ToString();
            //Debug.Log(buttonname);
        }
        else if(timer > 0){
            if(turncount == 0){
                if(flag){
                    //cubename = "Cube"+turncount.ToString();
                    //Debug.Log("OK!");
                    transform.Find(buttonname).gameObject.SetActive(true);
                    transform.Find(cubename).gameObject.SetActive(true);
                    flag = false;
                }
            }
            else if(turncount == 1){
                if(flag){
                    //cubename = "Cube"+turncount.ToString();
                    //Debug.Log("OK!");
                    transform.Find(buttonname).gameObject.SetActive(true);
                    transform.Find(cubename).gameObject.SetActive(true);
                    flag = false;
                }
            }
            else if(turncount == 2){
                if(flag){
                    //cubename = "Cube"+turncount.ToString();
                    //Debug.Log("OK!");
                    transform.Find(buttonname).gameObject.SetActive(true);
                    transform.Find(cubename).gameObject.SetActive(true);
                    flag = false;
                }
            }
            else{
                if(flag){
                    //cubename = "Cube"+turncount.ToString();
                    //Debug.Log("OK!");
                    transform.Find(buttonname).gameObject.SetActive(true);
                    transform.Find(cubename).gameObject.SetActive(true);
                    flag = false;
                }
            }
            timer -= Time.fixedDeltaTime;
        }
        else {
            Debug.Log(totalcount);
            turncount = (turncount+1)%4;
            btcount = (btcount+1)%8;
            totalcount++;
            transform.Find(buttonname).gameObject.SetActive(false);
            transform.Find(cubename).gameObject.SetActive(false);
            flag = true;
            
            if(totalcount == 16)
                gameObject.SetActive(false);
            timer = 1.8f;
	    }
    }
}

}