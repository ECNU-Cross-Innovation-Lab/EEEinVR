﻿// Copyright © 2018 – Property of Tobii AB (publ) - All Rights Reserved
using System.Collections;
using System.Collections.Generic;
using Tobii.G2OM;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

namespace Tobii.XR
{
//Monobehaviour which implements the "IGazeFocusable" interface, meaning it will be called on when the object receives focus
    public class GazeSucess : MonoBehaviour, IGazeFocusable
    {
        public float gazeCounter;
        public bool _hasFocus;
        //The method of the "IGazeFocusable" interface, which will be called when this object receives or loses focus
        public void GazeFocusChanged(bool hasFocus)
        {
            //If this object received focus, fade the object's color to highlight color
            if (hasFocus)
            {
                _hasFocus = hasFocus;
            }
            else{
                _hasFocus = hasFocus;
            }
        }

        void Start()
        {
            
        }

        void OnEnable(){
            gazeCounter = 0;
        }

        void Update()
        {
            
        }

        void FixedUpdate () {
            gazeCounter += Time.fixedDeltaTime;
            if(_hasFocus){
                //gazeCounter += Time.fixedDeltaTime;
                //StreamWriter sw = new StreamWriter("mydata.txt");
                //sw = sw.AppendText ();

                File.AppendAllText("mydata1.txt","Failed!\n");

                //sw.WriteLine(gazeCounter);
                //sw.Close();
                //gazeCounter = 0.8f;
                gameObject.SetActive(false);
                //if(gazeCounter >=0.8f){
                //    StreamWriter sw = new StreamWriter(mydata.txt);
                //    sw.WriteLine("重启次数：" + restartCnt.ToString());
                //    sw.Close();
                //    gameObject.SetActive(false);
                //}
            }
            else{
                //gazeCounter += Time.fixedDeltaTime;
                if(gazeCounter >=0.8f){
                    //File.AppendAllText("mydata1.txt","Sucessed!\n");
                    gameObject.SetActive(false);
                }
            }
        }
    }
}
