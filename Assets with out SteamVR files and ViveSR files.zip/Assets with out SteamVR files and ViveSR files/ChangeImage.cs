﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ChangeImage : MonoBehaviour
{
  public Image myImage;

   // Use this for initialization
    void Start()
    {
//需要自己在Assets下创建Resources文件夹，imagename是Resources下的图片名字
        myImage.sprite = Resources.Load("test", typeof(Sprite)) as Sprite;     // Image/pic 在 Assets/Resources/目录下
    }
}