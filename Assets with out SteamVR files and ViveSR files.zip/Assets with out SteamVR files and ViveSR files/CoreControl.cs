﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoreControl : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject gazepoint;
    void Start()
    {

        gazepoint.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
